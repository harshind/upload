//Complete the given scaffold to implement all the functionalities mentioned in the problem Statement.
const sentences = 
  `The quick brown fox jumps over the lazy dog.
  Sphinx of black quartz, judge my vow.
  Pack my box with five dozen liquor jugs.
  How vexingly quick daft zebras jump!`
;
const speed = (val)=>{
    //console.log(val)
    words = val.split(" ");
    let sentences_arr = sentences.split(" ")
    let count = 0;
    words.forEach((word, idx) => {
        if(sentences_arr[idx] == word){
            count++;
        }
    });
    return count * 2;
}

const accuracy = (val)=>{
    let count  = 0 ;
    Array.from(val).forEach((ch, idx) => {
        if(sentences[idx] == ch){
            count++;
        }
    });
    let accuracy = (count/ sentences.length) * 100;
    return accuracy.toFixed(2) ;
}

document.querySelector("#start-btn").addEventListener('click',()=>{
    document.querySelector("#input").disabled = false;
    document.querySelector("#start-btn").disabled = true;
    document.querySelector("#sentence").textContent = sentences;
    document.querySelector("#timer").textContent = "00:20";
    let timer = setInterval(()=>{
        let TimeerComp = document.querySelector("#timer")
        let currentTime = TimeerComp.textContent.split(":")[1];
        console.log(currentTime);
        currentTime = (parseInt(currentTime)-1)> 9 ? (parseInt(currentTime)-1): "0" + (parseInt(currentTime)-1);
        TimeerComp.textContent = "00:" + currentTime;
        if(currentTime == 0){
            clearInterval(timer);
            document.querySelector("#result").style.display = 'block';
            const InputComp = document.querySelector("#input")
            InputComp.disabled = true;
            const val = InputComp.value;
            const speedComp = document.querySelector("#speed")
            speedComp.textContent = speed(val) + speedComp.textContent;
            const accuracyComp = document.querySelector("#accuracy")
            accuracyComp.textContent = accuracy(val) + accuracyComp.textContent;
        }
    }, 1000);
})

document.querySelector("#retry-btn").addEventListener("click", ()=>{
    document.querySelector("#result").style.display = 'none';
    document.querySelector("#input").value = "";
    document.querySelector("#input").disabled = true;
    document.querySelector("#start-btn").disabled = false;
})