
const apikey = 'aa063f63a1b24c77142f3671f9ce4ec9';
const genreUrl = `https://api.themoviedb.org/3/genre/movie/list?api_key=aa063f63a1b24c77142f3671f9ce4ec9`
//https://api.themoviedb.org/3/discover/movie?api_key=${apiKey}&with_genres=${selectedGenre}

const xhr = new XMLHttpRequest();
xhr.open('GET', genreUrl);
xhr.responseType = 'json';
xhr.send();
xhr.onload = function () {
    if (xhr.status != 200) { // analyze HTTP status of the response
        alert(`Error ${xhr.status}: ${xhr.statusText}`); // e.g. 404: Not Found
    } else { // show the result
        let genreList = xhr.response["genres"];
        const genresComp = document.getElementById("genres")
        genresComp.innerHTML = ""
        console.log(genreList)
        genreList.forEach((genre) => {
            genresComp.innerHTML = genresComp.innerHTML + (`<option value= "${genre.id}">${genre.name} </option>`)
        });

    }
};

document.querySelector("#playBtn").addEventListener('click', (event) => {
    event.preventDefault();
    const selectedGenre = document.getElementById("genres").value;
    const movieByGenre = `https://api.themoviedb.org/3/genre/movie/list?api_key=aa063f63a1b24c77142f3671f9ce4ec9&with_genres=${selectedGenre}`

    console.log(genre)
    xhr.open('GET', movieByGenre);
    xhr.responseType = 'json';
    xhr.send();
    xhr.onload = function () {
        if (xhr.status != 200) { // analyze HTTP status of the response
            alert(`Error ${xhr.status}: ${xhr.statusText}`); // e.g. 404: Not Found
        } else { // show the result
            let movieList = xhr.response;
            const genresComp = document.getElementById("genres")
            genresComp.innerHTML = ""
            console.log(genreList)
            genreList.forEach((genre) => {
                genresComp.innerHTML = genresComp.innerHTML + (`<option value= "${genre.id}">${genre.name} </option>`)
            });

        }
    };

})