const songs = [
    { id: 1, name: "Tonight I'm loving U", artist: "Enrique Iglesias", img: "offlinemusicplayer/assets/compact-disk.jpg", genre: ["latin"], source: "" }
    , { id: 2, name: "Pop music", artist: "Enrique Iglesias", img: "offlinemusicplayer/assets/compact-disk.jpg", genre: ['pop'], source: "" }
    , { id: 3, name: "rock song", artist: "Enrique Iglesias", img: "offlinemusicplayer/assets/compact-disk.jpg", genre: ["rock"], source: "" }
    , { id: 4, name: "Chill", artist: "Enrique Iglesias", img: "offlinemusicplayer/assets/compact-disk.jpg", genre: ["chill"], source: "" }
    , { id: 5, name: "Tonight I'm loving U", artist: "Enrique Iglesias", img: "offlinemusicplayer/assets/compact-disk.jpg", genre: ["latin"], source: "" }

]

function toggleTheme() {
    const container = document.querySelector('.body');
    if (!localStorage.getItem("data-theme")) {
        localStorage.setItem("data-theme", "light");
        container.classList.add('light')
    } else {
        let currentTheme = localStorage.getItem("data-theme");
        container.classList.remove(currentTheme)
        currentTheme = currentTheme === "light" ? "dark" : "light";
        localStorage.setItem("data-theme", currentTheme);
        container.classList.add(currentTheme)
    }
    console.log(localStorage.getItem("data-theme"))
}
document.querySelector(".toggle").addEventListener('click', () => {
    const toggle = document.querySelector(".toggle")
    if (toggle.classList.contains("fa-toggle-off")) {
        toggle.classList.remove("fa-toggle-off")
        toggle.classList.add("fa-toggle-on")
    } else {
        toggle.classList.add("fa-toggle-off")
        toggle.classList.remove("fa-toggle-on")
    }
    toggleTheme()
})
// populate genre
const genreList = ["default", "pop", "latin", "chill", "rock"]
const genres = document.querySelector("#genre");
genres.innerHTML = "";
genreList.forEach((genre) => {
    genres.innerHTML = genres.innerHTML + `<option value="${genre}">${genre}</option>`;
})

function generatePlaylistCard(obj) {
    const card = `<div class="playlist-card" id ="${obj.id}">
    <span class="playlist-number" >${obj.number}</span>
    <img src="${obj.img}" alt="" class="playlist-icon" />
    <div class="playlist-info">
      <div class="song-name">${obj.name}</div>
      <div class="singer">${obj.artist}</div>
    </div>
    <span class="favourite"><i class="fa-regular fa-heart"></i></span>
  </div>`
    return card;
}

function generateCard(obj) {
    console.log(obj)
    const card = `
    <div class="card" style="width: 18rem;">
        <img src="${obj.img}" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title">${obj.name}</h5>
            <p class="card-text">${obj.artist}</p>
            <div class="row" style="height:50px;">
                <button id= "${obj.id}" class="col-lg-6 btn" >
                    <i class="fa-solid fa-arrow-left"></i>
                </button>
                <button id= "${obj.id}" class="col-lg-6 btn" >
                    <i class="fa-solid fa-arrow-right"></i>
                </button>
            </div>
            <div class="row" style="height:50px;">
                <button id= "${obj.id}" class="addtoplaylist" onclick = addtoPlaylist() >Add to Playlist</button>
            </div>
        </div>
    </div>`
    return card
}

function nextSong(id){
    console.log(id)
    const song = songs.filter(item=>{
        if(item.id == id + 1){
            return item
        }
    })
    console.log(song)
    renderCurrentSong(song)
}
function prevSong(id){
    const song = songs.filter(item=>{
        if(item.id == id - 1){
            return item
        }
    })
    renderCurrentSong(song)
}
function renderCurrentSong(song) {
    const musicCard = document.querySelector("#song-card");
    musicCard.innerHTML = generateCard(song)
}
function showSongs() {
    const genreSelected = document.querySelector("#genre").value;
    const songlist = document.querySelector("#song-list");
    songlist.innerHTML = ' '
    let filteredSong = songs;
    if (genreSelected == 'default') {
        filteredSong = songs;
    } else {
        filteredSong = songs.filter((item, idx) => {
            const g = item.genre
            if (g.findIndex((g) => g == genreSelected) != -1) {
                return item
            }
        })
    }
    console.log(filteredSong)
    filteredSong.forEach((item, idx) => {
        item["number"] = idx + 1;
        songlist.innerHTML = songlist.innerHTML + generatePlaylistCard(item)
    })

}
showSongs();
document.querySelector("#genre").addEventListener("change", () => {
    showSongs();
    addListener();
})
function findSongById(id) {
    return songs.filter(item => item.id == id)[0];
}
console.log(document.querySelectorAll(".playlist-card"))
function addListener() {
    Array.from(document.querySelectorAll(".playlist-card")).forEach((song, id) => {
        song.addEventListener('click', () => {
            const songObj = findSongById(song.id);
            renderCurrentSong(songObj);
        })
    })
}
addListener()
function generatePlaylist(obj) {

}
function renderPlaylist() {
    const playlistObj = JSON.parse(localStorage.getItem('playlist'));
    console.log(playlistObj)
    const allPlaylist = document.querySelector("#all-playlist");
    allPlaylist.innerHTML = `<div id="all-playlist" class="w-100">All Playlist</div>`
    if (playlistObj != undefined) {
        Object.keys(playlistObj).forEach((item, idx) => {
            //item["number"] = idx + 1;
            allPlaylist.innerHTML = allPlaylist.innerHTML + `<div class="playlists">${item}</div>`
        })
    }

}
renderPlaylist();
function createPlaylist() {
    const playlistName = document.querySelector("#playlist-name").value;
    const newObj = {}
    newObj[`${playlistName}`] = []
    console.log(newObj)
    if (!localStorage.getItem('playlist')) {
        localStorage.setItem('playlist', JSON.stringify(newObj));

    } else {
        const playlistObj = JSON.parse(localStorage.getItem('playlist'));
        if (playlistObj[playlistName] === undefined) {
            playlistObj[playlistName] = []
        } else {
            alert("playlist already exists")
        }

        localStorage.setItem('playlist', JSON.stringify(playlistObj))
        console.log(localStorage.getItem('playlist'));
        renderPlaylist();
    }
}
document.querySelector("#create-playlist").addEventListener('click', () => {
    createPlaylist()
})
let currentPlaylist;
Array.from(document.querySelectorAll(".playlists")).forEach(playlist => {
    playlist.addEventListener('click', (event) => {
        currentPlaylist = event.target.textContent;
        console.log(currentPlaylist)
        renderPlaylistSong()
    })
})

function addtoPlaylist() {
    const playlistObj = JSON.parse(localStorage.getItem('playlist'));
    const id = document.querySelector(".addtoplaylist").id;
    let song = songs.filter((item) => {
        if (item.id == id) {
            return item;
        }
    })
    if (currentPlaylist == undefined) {
        alert("please select the playlist");
    } else {
        playlistObj[currentPlaylist].push(song);
        console.log(playlistObj)
        localStorage.setItem('playlist', JSON.stringify(playlistObj))
    }
    renderPlaylistSong();
}

function renderPlaylistSong() {
    const playlistObj = JSON.parse(localStorage.getItem('playlist'));
    const currentPlaylistComp = document.querySelector("#current-playlist");
    currentPlaylistComp.innerHTML = `<div id="current-playlist" class="w-100">Current Playlist</div>`
    if (currentPlaylist) {
        playlistObj[currentPlaylist].forEach((item) => {
            console.log(item)
            currentPlaylistComp.innerHTML = currentPlaylistComp.innerHTML + `<div id="${item[0].id}" class="">${item[0].name}</div>`;
        })
    }
}
renderPlaylistSong()