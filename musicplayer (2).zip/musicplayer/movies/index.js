//Create you project here from scratch
const moviesList = [
    { movieName: "Flash", price: 7 },
    { movieName: "Spiderman", price: 5 },
    { movieName: "Batman", price: 4 },
];

// Use moviesList array for displaing the Name in the dropdown menu id="selectMovie" 
//<option value="dog">Dog</option>
const movies = document.getElementById("selectMovie")
movies.innerHTML = ""
moviesList.forEach((movie) => {
    movies.innerHTML = movies.innerHTML + (`<option value= "${movie.movieName}+${movie.price}">${movie.movieName} ${movie.price}</option>`)
});

movies.addEventListener('change', () => {
    const [name, price] = movies.value.split("+");
    document.getElementById('movieName').textContent = name;
    document.getElementById('moviePrice').textContent = `$ ${price}`;
    let totalPrice = document.getElementById("totalPrice").textContent.split(" ")[1];
    const seatCount = document.getElementById("numberOfSeat");
    totalPrice = (parseInt(seatCount.textContent) * parseInt(price));
    document.getElementById("totalPrice").textContent = `$ ${totalPrice}`;
})


//Add eventLister to each unoccupied seat class="seat occupied"
Array.from(document.querySelectorAll('.seat')).slice(3).forEach((seat, idx) => {
    seat.addEventListener('click', () => {

        const seatCount = document.getElementById("numberOfSeat");
        let totalPrice = document.getElementById("totalPrice").textContent.split(" ")[1];
        const moviePrice = document.getElementById('moviePrice').textContent.split(" ")[1];
        let seatcontainer = document.querySelector('#selectedSeatsHolder');
        console.log(seatcontainer)
        //console.log(moviePrice, totalPrice)
        if (!seat.classList.contains('selected') && !seat.classList.contains('occupied')) {
            seat.classList.add('selected');
            seatCount.textContent = parseInt(seatCount.textContent) + 1;
            // Adding seat to seat container
            if (seatcontainer.children[0].classList.contains("noSelected")) {
                seatcontainer.removeChild(seatcontainer.firstChild)
            }
            const span = document.createElement('span')
            span.textContent = idx;
            seatcontainer.appendChild(span);

        } else if (seat.classList.contains('occupied')) { }
        else {
            seat.classList.remove('selected');
            seatCount.textContent = parseInt(seatCount.textContent) - 1;
            console.log(seatcontainer.children)
            Array.from(seatcontainer.children).forEach((elem) => {
                if (elem.textContent == idx) {
                    seatcontainer.removeChild(elem);
                }
            })
            if (seatcontainer.childElementCount == 0) {
                const span = document.createElement('span');
                span.classList.add("noSelected");
                span.textContent = "No Seat Selected"
                seatcontainer.appendChild(span)
            }
        }
        totalPrice = (parseInt(seatCount.textContent) * parseInt(moviePrice));
        document.getElementById("totalPrice").textContent = `$ ${totalPrice}`;
    })
})

//Add eventLsiter to continue Button id="proceedBtn"
document.querySelector('#proceedBtn').addEventListener('click', () => {
    const selectedSeats = Array.from(document.querySelectorAll(".selected")).slice(1);
    if (selectedSeats.length == 0) {
        alert("Oops no seat Selected")
    } else {
        selectedSeats.forEach((seat) => {
            seat.classList.remove("selected");
            seat.classList.add("occupied");
            document.getElementById("totalPrice").textContent = `$ 0`;
            document.getElementById("numberOfSeat").textContent = '0';
            let seatcontainer = document.getElementById("selectedSeatsHolder")
            while (seatcontainer.hasChildNodes()) {
                seatcontainer.removeChild(seatcontainer.firstChild);
            }
            const span = document.createElement('span');
            span.classList.add("noSelected");
            span.textContent = "No Seat Selected"
            seatcontainer.appendChild(span)
        });
        alert("Yayy! Your Seats have been booked");
    }
})

//Add eventListerner to Cancel Button id="cancelBtn"
document.querySelector("#cancelBtn").addEventListener('click', () => {
    const selectedSeats = document.querySelectorAll(".selected");
    if (selectedSeats.length == 0) {
        alert("Oops no seat Selected")
    } else {
        selectedSeats.forEach((seat) => {
            seat.classList.remove("selected");
            document.getElementById("totalPrice").textContent = `$ 0`;
            document.getElementById("numberOfSeat").textContent = '0';
            let seatcontainer = document.getElementById("selectedSeatsHolder")
            while (seatcontainer.hasChildNodes()) {
                seatcontainer.removeChild(seatcontainer.firstChild);
            }
            const span = document.createElement('span');
            span.classList.add("noSelected");
            span.textContent = "No Seat Selected"
            seatcontainer.appendChild(span)
        });
    }
})